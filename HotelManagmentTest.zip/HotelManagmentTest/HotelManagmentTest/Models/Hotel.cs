﻿using Google.Rpc;

namespace HotelManagmentTest.Models
{
    public class Hotel
    {
        public int HotelId { get; set; }
        public string Name { get; set; }
        public string Discription { get; set; }
        public string CountryCode { get; set; }
        public string StateCode { get; set; }
        public string City { get; set; }
        public string Postal Code { get; set; }
    }
}
