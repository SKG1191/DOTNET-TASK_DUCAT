﻿namespace HotelManagmentTest.Models
{
    public class RoomFacility
    {
    }
}
