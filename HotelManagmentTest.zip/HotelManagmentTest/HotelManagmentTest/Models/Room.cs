﻿namespace HotelManagmentTest.Models
{
    public class Room
    {
    }
}
