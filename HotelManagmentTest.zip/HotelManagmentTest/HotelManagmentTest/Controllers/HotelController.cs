﻿using Microsoft.AspNetCore.Mvc;

namespace HotelManagmentTest.Controllers
{
    public class HotelController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
